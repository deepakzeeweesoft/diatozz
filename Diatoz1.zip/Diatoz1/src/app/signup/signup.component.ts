import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  signupForm!: FormGroup;
  submitted = false;
  
  constructor(private formBuilder: FormBuilder,private router:Router) { }

  ngOnInit(): void {
    this.signupForm = this.formBuilder.group({
      
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(8)]],
      confirmPassword: ['', Validators.required],
      acceptTerms: [false, Validators.requiredTrue]
    });
  }

  get f() { return this.signupForm.controls; }

  onSubmit() {
    this.submitted = true;

    // stop here if form is invalid
    if (this.signupForm.invalid) {
      return;
    }

    localStorage.setItem('FirstName',this.signupForm.value.firstName)
    localStorage.setItem('Email',this.signupForm.value.email)
    localStorage.setItem('Password',this.signupForm.value.password)
  
            console.log('FirstName',this.signupForm.value.firstName);
            alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.signupForm.value, null, 4));
            this.router.navigate(['/Login']);

  }

        



  onReset() {
    this.submitted = false;
    this.signupForm.reset();
  }
}
