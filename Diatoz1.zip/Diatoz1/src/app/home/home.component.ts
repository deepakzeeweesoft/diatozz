import { Component, OnInit } from '@angular/core';
import{FlickrService} from './../service/flickr.service';
import { observable, Observable } from 'rxjs';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  homeList: any;

  constructor(private flickrService:FlickrService) { }

  ngOnInit(): void {

    //this.getImages();  

this.flickrService.getImage().subscribe(data=>{
  this.homeList=data;
  console.log(this.homeList)
})

  }

 
    
  clear()
  {
    console.log("work");
  }        
     

  // async getImages()
  //        {
  //              let result=await this.get(this.apiUrl.)    
  //        }

}
