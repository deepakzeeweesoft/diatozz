import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders, HttpParams, HttpResponse} from '@angular/common/http';
import {map,catchError, retry} from 'rxjs/operators';
import {environment} from 'src/environments/environment'
import { Observable } from 'rxjs/internal/Observable';

export interface FlickrPhoto {
  farm: string;
  id: string;
  secret: string;
  server: string;
  title: string;
}

export interface FlickrOutput {
  photos: {
    photo: FlickrPhoto[];
  };
}


@Injectable({
  providedIn: 'root'
})
export class FlickrService {

  API_KEY = '636e1481b4f3c446d26b8eb6ebfe7127';

  prevKeyword!: string;
  currPage = 1;
  constructor(private api:HttpClient) { }             
            getImage()
            {
              return this.api.get('https://api.flickr.com/services/rest/?method=flickr.photos.search&api_key=636e1481b4f3c446d26b8eb6ebfe7127&tags=beach&per_page=24&format=json&nojsoncallback=1')
            }

  // search_keyword(keyword: string)
  //    {
  //     if (this.prevKeyword === keyword) {
  //       this.currPage++;
  //     } else {
  //       this.currPage = 1;
  //     }
  //     this.prevKeyword = keyword;
  //      const url = 'http://www.flickr.com/services/rest/?method=flickr.photos.search&'

  //      const params=`api_key=${flickr.key}&tags=${tag}&per_page=24&format=json&nojsoncallback=1`;

            
  //   //    return this.http.get(url + params).pipe(map((res: FlickrOutput) => {
  //   //     const urlArr = [];
  //   //     res.photos.photo.forEach((ph: FlickrPhoto) => {
  //   //       const photoObj = {
  //   //         url: `https://farm${ph.farm}.staticflickr.com/${ph.server}/${ph.id}_${ph.secret}`,
  //   //         title: ph.title
  //   //       };
  //   //       urlArr.push(photoObj);
  //   //     });
  //   //     return urlArr;
  //   //   }));
  //   // }
    
  // }



  // public getNews(){
  //   return this.httpClient.get(`https://api.flickr.com/services/rest/?method=flickr.photos.search& 
  //   api_key=${ this.API_KEY}`);
  // }

//   get(url: string, options: {
//     headers?: HttpHeaders;
//     observe: 'response';
//     params?: HttpParams;
//     reportProgress?: boolean;
//     responseType?: 'json';
//     withCredentials?: boolean;
// }): Observable<HttpResponse<Object>>;

}
     






  